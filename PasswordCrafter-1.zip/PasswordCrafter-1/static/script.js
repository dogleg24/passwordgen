// Password Generator JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // DOM elements
    const lengthSlider = document.getElementById('passwordLength');
    const lengthValue = document.getElementById('lengthValue');
    const generateBtn = document.getElementById('generateBtn');
    const passwordCard = document.getElementById('passwordCard');
    const generatedPassword = document.getElementById('generatedPassword');
    const copyBtn = document.getElementById('copyBtn');
    const toggleVisibility = document.getElementById('toggleVisibility');
    const visibilityIcon = document.getElementById('visibilityIcon');
    const strengthLevel = document.getElementById('strengthLevel');
    const strengthBar = document.getElementById('strengthBar');
    const strengthFeedback = document.getElementById('strengthFeedback');
    const feedbackList = document.getElementById('feedbackList');

    // Password strength checker elements
    const checkPassword = document.getElementById('checkPassword');
    const checkStrengthBtn = document.getElementById('checkStrengthBtn');
    const toggleCheckVisibility = document.getElementById('toggleCheckVisibility');
    const checkVisibilityIcon = document.getElementById('checkVisibilityIcon');
    const checkResults = document.getElementById('checkResults');
    const checkStrengthLevel = document.getElementById('checkStrengthLevel');
    const checkStrengthBar = document.getElementById('checkStrengthBar');
    const checkStrengthFeedback = document.getElementById('checkStrengthFeedback');
    const checkFeedbackList = document.getElementById('checkFeedbackList');

    // Update length display
    lengthSlider.addEventListener('input', function() {
        lengthValue.textContent = this.value;
    });

    // Generate password button
    generateBtn.addEventListener('click', function() {
        generatePassword();
    });

    // Copy to clipboard
    copyBtn.addEventListener('click', function() {
        copyToClipboard();
    });

    // Toggle password visibility
    toggleVisibility.addEventListener('click', function() {
        togglePasswordVisibility();
    });

    // Toggle check password visibility
    toggleCheckVisibility.addEventListener('click', function() {
        toggleCheckPasswordVisibility();
    });

    // Check password strength
    checkStrengthBtn.addEventListener('click', function() {
        checkPasswordStrength();
    });

    // Check password on Enter key
    checkPassword.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            checkPasswordStrength();
        }
    });

    // Real-time password strength checking
    checkPassword.addEventListener('input', function() {
        if (this.value.length > 0) {
            debounce(checkPasswordStrength, 500)();
        } else {
            checkResults.style.display = 'none';
        }
    });

    function generatePassword() {
        const length = parseInt(lengthSlider.value);
        const includeUppercase = document.getElementById('includeUppercase').checked;
        const includeLowercase = document.getElementById('includeLowercase').checked;
        const includeNumbers = document.getElementById('includeNumbers').checked;
        const includeSpecial = document.getElementById('includeSpecial').checked;

        // Validate that at least one character type is selected
        if (!includeUppercase && !includeLowercase && !includeNumbers && !includeSpecial) {
            showAlert('Please select at least one character type!', 'warning');
            return;
        }

        // Show loading state
        generateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
        generateBtn.disabled = true;

        const data = {
            length: length,
            uppercase: includeUppercase,
            lowercase: includeLowercase,
            numbers: includeNumbers,
            special: includeSpecial
        };

        fetch('/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showAlert(data.error, 'danger');
            } else {
                displayGeneratedPassword(data.password, data.strength);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('An error occurred while generating the password', 'danger');
        })
        .finally(() => {
            // Reset button state
            generateBtn.innerHTML = '<i class="fas fa-magic me-2"></i>Generate Password';
            generateBtn.disabled = false;
        });
    }

    function displayGeneratedPassword(password, strength) {
        generatedPassword.value = password;
        passwordCard.style.display = 'block';
        passwordCard.classList.add('fade-in');
        
        // Reset visibility to hidden
        generatedPassword.type = 'password';
        visibilityIcon.className = 'fas fa-eye';
        
        updateStrengthDisplay(strength, strengthLevel, strengthBar, strengthFeedback, feedbackList);
        
        // Scroll to the password card
        passwordCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function copyToClipboard() {
        generatedPassword.select();
        generatedPassword.setSelectionRange(0, 99999); // For mobile devices
        
        navigator.clipboard.writeText(generatedPassword.value).then(function() {
            // Show success feedback
            copyBtn.classList.add('copy-success');
            const originalHTML = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
            copyBtn.classList.add('text-success');
            
            setTimeout(() => {
                copyBtn.innerHTML = originalHTML;
                copyBtn.classList.remove('text-success', 'copy-success');
            }, 1500);
            
            showAlert('Password copied to clipboard!', 'success');
        }).catch(function(err) {
            console.error('Could not copy text: ', err);
            showAlert('Failed to copy password', 'danger');
        });
    }

    function togglePasswordVisibility() {
        if (generatedPassword.type === 'password') {
            generatedPassword.type = 'text';
            visibilityIcon.className = 'fas fa-eye-slash';
        } else {
            generatedPassword.type = 'password';
            visibilityIcon.className = 'fas fa-eye';
        }
    }

    function toggleCheckPasswordVisibility() {
        if (checkPassword.type === 'password') {
            checkPassword.type = 'text';
            checkVisibilityIcon.className = 'fas fa-eye-slash';
        } else {
            checkPassword.type = 'password';
            checkVisibilityIcon.className = 'fas fa-eye';
        }
    }

    function checkPasswordStrength() {
        const password = checkPassword.value.trim();
        
        if (!password) {
            showAlert('Please enter a password to check', 'warning');
            return;
        }

        checkStrengthBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Checking...';
        checkStrengthBtn.disabled = true;

        fetch('/check-strength', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ password: password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showAlert(data.error, 'danger');
            } else {
                displayPasswordStrength(data.strength);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('An error occurred while checking password strength', 'danger');
        })
        .finally(() => {
            checkStrengthBtn.innerHTML = '<i class="fas fa-shield-alt me-2"></i>Check';
            checkStrengthBtn.disabled = false;
        });
    }

    function displayPasswordStrength(strength) {
        checkResults.style.display = 'block';
        checkResults.classList.add('fade-in');
        updateStrengthDisplay(strength, checkStrengthLevel, checkStrengthBar, checkStrengthFeedback, checkFeedbackList);
    }

    function updateStrengthDisplay(strength, levelElement, barElement, feedbackElement, listElement) {
        // Update strength level badge
        levelElement.textContent = strength.level;
        levelElement.className = `badge bg-${strength.color}`;
        
        // Update progress bar
        barElement.style.width = strength.score + '%';
        barElement.className = `progress-bar bg-${strength.color}`;
        barElement.setAttribute('aria-valuenow', strength.score);
        
        // Update feedback
        if (strength.feedback && strength.feedback.length > 0) {
            feedbackElement.style.display = 'block';
            feedbackElement.className = `alert alert-${strength.color}`;
            
            listElement.innerHTML = '';
            strength.feedback.forEach(item => {
                const li = document.createElement('li');
                li.textContent = item;
                listElement.appendChild(li);
            });
        } else {
            feedbackElement.style.display = 'none';
        }
    }

    function showAlert(message, type) {
        // Create alert element
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    // Debounce function for real-time checking
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + Enter to generate password
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            generatePassword();
        }
        
        // Ctrl/Cmd + C to copy password (when password card is visible)
        if ((e.ctrlKey || e.metaKey) && e.key === 'c' && passwordCard.style.display !== 'none') {
            if (document.activeElement !== checkPassword) {
                e.preventDefault();
                copyToClipboard();
            }
        }
    });
});
