# Import necessary modules:
# 'random' is used for generating random choices (for the password generation).
# 'string' provides easy access to common sets of characters like lowercase letters, digits, and punctuation.
import random
import string

# --- Main Program Function ---
# This function serves as the entry point and main control flow for the application.
# It presents a menu to the user and directs them to either generate a password,
# check a password's strength, or exit the program.
def main():
    """
    Manages the overall flow of the password utility application.
    Presents a menu and handles user interaction for choosing features.
    """
    while True: # This 'while True' loop keeps the program running until the user explicitly chooses to exit.
        print("\n--- Welcome to the Advanced Password Utility! ---")
        print("1. Generate a New Strong Password")
        print("2. Check Password Strength")
        print("3. Exit Program")

        # Get user input for their choice and remove any leading/trailing whitespace.
        user_choice = input("Please enter your choice (1, 2, or 3): ").strip()

        # Use if/elif/else statements to navigate based on user's input.
        if user_choice == '1':
            generate_password() # Call the function to handle password generation.
        elif user_choice == '2':
            check_password_strength() # Call the function to handle password strength checking.
        elif user_choice == '3':
            print("Thank you for using the password utility. Goodbye!")
            break # The 'break' statement exits the 'while True' loop, effectively ending the program.
        else:
            # If the user enters anything other than '1', '2', or '3', display an error message.
            print("Invalid choice. Please enter '1' for generation, '2' for checking, or '3' to exit.")

# --- Password Generation Function ---
# This function is responsible for creating a random password based on criteria provided by the user.
def generate_password():
    """
    Generates a random password based on user-defined length and character set preferences.
    """
    print("\n--- Password Generator ---")

    # Loop to ensure the user provides a valid positive integer for password length.
    while True:
        try:
            # Prompt the user for the desired password length.
            # int() attempts to convert the input string into an integer.
            password_length = int(input("Enter desired password length (e.g., 12 for robust security): "))
            if password_length <= 0:
                print("Password length must be a positive number. Please try again.")
            else:
                break # Exit the loop if a valid positive integer is entered.
        except ValueError:
            # Catch 'ValueError' if the user enters non-numeric input (e.g., text).
            print("Invalid input. Please enter a whole number (e.g., 8, 12, 16) for the length.")

    # Get user preferences for which types of characters to include in the password.
    # .lower() converts input to lowercase to make checks case-insensitive.
    # '== 'yes'' evaluates to True if the lowercase input is "yes", otherwise False.
    include_uppercase = input("Include uppercase letters (A-Z)? (yes/no): ").lower().strip() == 'yes'
    include_lowercase = input("Include lowercase letters (a-z)? (yes/no): ").lower().strip() == 'yes'
    include_numbers = input("Include numbers (0-9)? (yes/no): ").lower().strip() == 'yes'
    include_special = input("Include special characters (!@#$%^&* etc.)? (yes/no): ").lower().strip() == 'yes'

    # Check if at least one character type is selected
    if not any([include_uppercase, include_lowercase, include_numbers, include_special]):
        print("Error: You must select at least one character type! Please try again.")
        return  # Return to the main menu if no character types are selected

    # Build the character set based on user preferences
    # Start with an empty string to hold all possible characters
    character_set = ""
    
    # Add character types based on user selections
    if include_uppercase:
        character_set += string.ascii_uppercase  # Adds A-Z
    if include_lowercase:
        character_set += string.ascii_lowercase  # Adds a-z
    if include_numbers:
        character_set += string.digits  # Adds 0-9
    if include_special:
        character_set += "!@#$%^&*()_+-=[]{}|;:,.<>?"  # Adds special characters

    # Generate the password ensuring at least one character from each selected type
    password = []
    
    # First, add at least one character from each selected type to guarantee variety
    if include_uppercase:
        password.append(random.choice(string.ascii_uppercase))
    if include_lowercase:
        password.append(random.choice(string.ascii_lowercase))
    if include_numbers:
        password.append(random.choice(string.digits))
    if include_special:
        password.append(random.choice("!@#$%^&*()_+-=[]{}|;:,.<>?"))
    
    # Fill the remaining password length with random characters from the full character set
    for _ in range(password_length - len(password)):
        password.append(random.choice(character_set))
    
    # Shuffle the password list to avoid predictable patterns (like having all uppercase first)
    random.shuffle(password)
    
    # Convert the list of characters to a single string
    final_password = ''.join(password)
    
    # Display the generated password to the user
    print(f"\n✓ Your generated password is: {final_password}")
    print(f"✓ Password length: {len(final_password)} characters")
    
    # Show what character types were included
    types_included = []
    if include_uppercase:
        types_included.append("uppercase letters")
    if include_lowercase:
        types_included.append("lowercase letters")
    if include_numbers:
        types_included.append("numbers")
    if include_special:
        types_included.append("special characters")
    
    print(f"✓ Includes: {', '.join(types_included)}")

# --- Password Strength Checking Function ---
# This function analyzes a password and gives feedback on its strength
def check_password_strength():
    """
    Analyzes a user-provided password and gives detailed feedback on its strength.
    """
    print("\n--- Password Strength Checker ---")
    
    # Get password from user
    password = input("Enter a password to check its strength: ").strip()
    
    # Check if password is empty
    if not password:
        print("Error: Password cannot be empty!")
        return
    
    # Initialize strength score and feedback list
    strength_score = 0
    feedback = []
    
    # Check password length
    length = len(password)
    if length >= 12:
        strength_score += 25
        feedback.append("✓ Good length (12+ characters)")
    elif length >= 8:
        strength_score += 15
        feedback.append("! Consider using at least 12 characters for better security")
    else:
        strength_score += 5
        feedback.append("✗ Password is too short - use at least 8 characters")
    
    # Check for character variety
    has_uppercase = any(c.isupper() for c in password)
    has_lowercase = any(c.islower() for c in password)
    has_numbers = any(c.isdigit() for c in password)
    has_special = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
    
    character_types = sum([has_uppercase, has_lowercase, has_numbers, has_special])
    
    if character_types >= 4:
        strength_score += 25
        feedback.append("✓ Excellent character variety (all types included)")
    elif character_types >= 3:
        strength_score += 20
        feedback.append("✓ Good character variety")
        if not has_special:
            feedback.append("! Consider adding special characters")
    elif character_types >= 2:
        strength_score += 10
        feedback.append("! Use more character types for better security")
    else:
        strength_score += 5
        feedback.append("✗ Password should contain different types of characters")
    
    # Check for repeated characters
    has_repeated = any(password[i] == password[i+1] == password[i+2] for i in range(len(password)-2))
    if not has_repeated:
        strength_score += 15
        feedback.append("✓ No repeated character patterns")
    else:
        feedback.append("✗ Avoid repeating the same character multiple times")
    
    # Check for common patterns
    common_patterns = ['123', 'abc', 'qwe', 'asd', 'zxc', 'password', '12345']
    has_common_pattern = any(pattern in password.lower() for pattern in common_patterns)
    if not has_common_pattern:
        strength_score += 15
        feedback.append("✓ No common patterns detected")
    else:
        feedback.append("✗ Avoid common patterns like '123', 'abc', or 'password'")
    
    # Bonus for very long passwords with good variety
    if length > 16 and character_types >= 3:
        strength_score += 20
        feedback.append("✓ Bonus points for exceptional length and variety!")
    
    # Determine overall strength level
    if strength_score >= 90:
        strength_level = "Very Strong"
        strength_color = "🟢"
    elif strength_score >= 70:
        strength_level = "Strong"
        strength_color = "🟢"
    elif strength_score >= 50:
        strength_level = "Moderate"
        strength_color = "🟡"
    elif strength_score >= 30:
        strength_level = "Weak"
        strength_color = "🟠"
    else:
        strength_level = "Very Weak"
        strength_color = "🔴"
    
    # Display results
    print(f"\n{strength_color} Password Strength: {strength_level}")
    print(f"Security Score: {min(strength_score, 100)}/100")
    print("\nDetailed Analysis:")
    for item in feedback:
        print(f"  {item}")
    
    # Provide additional recommendations
    if strength_score < 70:
        print("\n💡 Recommendations for a stronger password:")
        print("  • Use at least 12 characters")
        print("  • Mix uppercase and lowercase letters")
        print("  • Include numbers and special characters")
        print("  • Avoid common words and patterns")
        print("  • Make it unique - don't reuse passwords")

# --- Program Entry Point ---
# This ensures the main() function runs only when the script is executed directly,
# not when it's imported as a module in another script.
if __name__ == "__main__":
    main()